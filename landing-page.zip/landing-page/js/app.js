/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
*/

/**
 * Define Global Variables
 *
*/


// build the nav
                              //*********craet varible section and queries all section and put in Variable sections
const sections =document.querySelectorAll('section');
                              //*********craet varible myUl and queries by id ( navbar__list) and put in Variable myUl
const myUl = document.getElementById('navbar__list');
                                //****create fragment->varable fragment
  var fragment = document.createDocumentFragment();
                                //******craete forEach in all sections that found in html
sections.forEach((section) => {

                                //craete varable text and put method getAttribute ('data-nave') in every section
  let text=section.getAttribute('data-nav');

                                  //craete new li
  let newLi =document.createElement('li');
                                  //add every li created in variable fragment
fragment.appendChild(newLi);

                                  //craete new hyber link
    let newLink =document.createElement('a');
                                  //add method that when we click on link going on section
  newLink.addEventListener('click',function(){
    section.scrollIntoView({behavior:"smooth"});
    });
                                  //add every links created in variable newLi
      newLi.appendChild(newLink);
                                  //create textNode and put the the created varible text
      let textNode =document.createTextNode(text);
                                  //add every textNode created in variable newLink
      newLink.appendChild(textNode);
});
                                  //add fragment that contain every li in variable myUl
myUl.appendChild(fragment);

// Add class 'active' to section when near top of viewport

function actLink(section) {
                              //create var links and queries to all links that created and put them in tis var
  let links =document.querySelectorAll('a');
                                //craete var put method getAttribute ('data-nave') in active section
  let secNav =section.getAttribute('data-nav');
                              //create forof to all links
for(link of links){
                              //if contain any link ==secNav
  if (link.textContent == secNav){
                              //queris all links and put them in variable links
let links=document.querySelectorAll('a')
for(link of links){
                              // remove any class that containing class->your-active-class
        link.classList.remove("actClass");
  }
                              //then add class-> your-active-class
    link.classList.add('actClass');
    }
  }
}

function actSc(){
                                  //create foreach on every section
sections.forEach((section) => {
                                    //get method getBoundingClientRect()in variable box
  let box =section.getBoundingClientRect();
                                    //if high level of section >0 so its in viewport
    if (box.top>=0 && box.bottom < window.innerHeight) {

sections.forEach((section) => {
                                  //remove any active class if found
    section.classList.remove("actClass");
});
                                    //add my new active class
      section.classList.add('actClass');
                                    //calling function actlink and pass parameter section that be active
actLink(section);

}

});


}
                                    //add method addEventListener to window when move the scroll doind the function active_fun
window.addEventListener("scroll",actSc);

// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 *
*/


// Build menu

// Scroll to section on link click

// Set sections as active
