# Landing Page Project
containing four sections by html and create 4 navbar links by java script in file app.js

and when click on any link in nav bar that going to active section

and by scrolling the active section in window will contain the class actClass

## Table of Contents
in app.js
i created variable that queris to all section and var fragment
and created forEach on all section to create anchortage and li and textContent
and created two function
that one use method getBoundingClientRect() in for loop
and check if top of section >0 or not and forloop all section to remove any active class if found finally adding my new active class as such as links function
* [Instructions](#instructions)


## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open `js/app.js` and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.
